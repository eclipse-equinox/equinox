/*
 * $Header: /cvshome/build/org.osgi.service.application/src/org/osgi/service/application/ApplicationDescriptor.java,v 1.27 2005/05/13 20:34:02 hargrave Exp $
 * 
 * Copyright (c) OSGi Alliance (2004, 2005). All Rights Reserved.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this 
 * distribution, and is available at http://www.eclipse.org/legal/epl-v10.html.
 */

package org.osgi.service.application;

import java.io.IOException;
import java.util.Map;

import org.osgi.framework.Constants;

/**
 * An OSGi service that represents an installed application and stores
 * information about it. The application descriptor can be used for instance
 * creation.
 */

public abstract class ApplicationDescriptor {

	/**
	 * The property key for the localized name of the application.
	 */
	public static final String APPLICATION_NAME = "application.name";

	/**
	 * The property key for the localized icon of the application.
	 */
	public static final String APPLICATION_ICON = "application.icon";

	/**
	 * The property key for the unique identifier (PID) of the application.
	 */
	public static final String APPLICATION_PID = Constants.SERVICE_PID;

	/**
	 * The property key for the version of the application.
	 */
	public static final String APPLICATION_VERSION = "application.version";

	/**
	 * The property key for the name of the application vendor.
	 */
	public static final String APPLICATION_VENDOR = "application.vendor";

	/**
	 * The property key for the singleton property of the application.
	 */
	public static final String APPLICATION_SINGLETON = "application.singleton";

	/**
	 * The property key for the autostart property of the application.
	 */
	public static final String APPLICATION_AUTOSTART = "application.autostart";

	/**
	 * The property key for the visibility property of the application.
	 */
	public static final String APPLICATION_VISIBLE = "application.visible";

	/**
	 * The property key for the launchable property of the application.
	 */
	public static final String APPLICATION_LAUNCHABLE = "application.launchable";

	/**
	 * The property key for the locked property of the application.
	 */
	public static final String APPLICATION_LOCKED = "application.locked";

	/**
	 * The property key for the localized description of the application.
	 */
	public static final String APPLICATION_DESCRIPTION = "application.description";

	/**
	 * The property key for the localized documentation of the application.
	 */
	public static final String APPLICATION_DOCUMENTATION = "application.documentation";

	/**
	 * The property key for the localized copyright notice of the application.
	 */
	public static final String APPLICATION_COPYRIGHT = "application.copyright";

	/**
	 * The property key for the localized license of the application.
	 */
	public static final String APPLICATION_LICENSE = "application.license";

	
	/**
	 * Constructs the <code>ApplicationDescriptor</code>.
	 *
	 * @param applicationId
	 *            The identifier of the application. Its value is also available
	 *            as the <code>service.pid</code> service property of this 
	 *            <code>ApplicationDescriptor</code> service.
	 */
	protected  ApplicationDescriptor(String pid) {
		this.pid = pid;
		try {
			delegate = (Delegate) implementation
					.newInstance();
			delegate.setApplicationDescriptor( this, pid );
		}
		catch (Exception e) {
			// Too bad ...
			e.printStackTrace();
			System.err
					.println("No implementation available for ApplicationDescriptor, property is: "
							+ cName);
		}
	}

	/**
	 * Returns the identifier of the represented application.
	 * 
	 * @return the identifier of the represented application
	 */
	protected final String getApplicationId() {
		return pid;
	}

	/**
	 * Returns the properties of the application descriptor as key-value pairs.
	 * The return value contains the locale aware and unaware properties as
	 * well. Some of the properties can be retrieved directly with methods in
	 * this interface. The returned <code>Map</code> will include the service
	 * properties of this <code>ApplicationDescriptor</code> as well.
	 * 
	 * This method will call the <code>getPropertiesSpecific</code> method
	 * to enable the container implementation to insert application model and/or
	 * container implementation specific properties.
	 * 
	 * @param locale
	 *            the locale string, it may be null, the value null means the
	 *            default locale. If the provided locale is the empty String 
	 *            (<code>""</code>)then raw (non-localized) values are returned.
	 * 
	 * @return service properties of this application descriptor service,
	 *         according to the specified locale. If locale is null then the
	 *         default locale's properties will be returned. (Since service
	 *         properties are always exist it cannot return null.)
	 * 
	 * @throws IllegalStateException
	 *             if the application descriptor is unregistered
	 */
	public final Map getProperties(String locale) {
		Map props = getPropertiesSpecific( locale );
		
		boolean isLocked = delegate.isLocked();
		Boolean wasLocked = Boolean.valueOf( (String)props.remove( APPLICATION_LOCKED ) );
		if( wasLocked != null && wasLocked.booleanValue() != isLocked ) {
			if( isLocked )
				lockSpecific();
			else
				unlockSpecific();
		}			
		props.put( APPLICATION_LOCKED, new Boolean( isLocked ) );
		
		return getPropertiesSpecific( locale );
	}
	
	/**
	 * Container implementations can provide application model specific
	 * and/or container implementation specific properties via this 
	 * method. 
	 * 
	 * Localizable properties must be returned localized if the provided
	 * <code>locale</code> argument is not the empty String. The value
	 * <code>null</code> indicates to use the default locale, for other
	 * values the specified locale should be used. 
	 *
	 * @param locale the locale to be used for localizing the properties.
	 * If <code>null</code> the default locale should be used. If it is
	 * the empty String (<code>""</code>) then raw (non-localized) values
	 * should be returned.
	 * 
	 * @return the application model specific and/or container implementation
	 * specific properties of this application descriptor. 
	 */
	protected abstract Map getPropertiesSpecific(String locale);

	/**
	 * Launches a new instance of an application. The args parameter specifies
	 * the startup parameters for the instance to be launched, it may be null.
	 * <p>
	 * The following steps are made:
	 * <UL>
	 * <LI>Check for the appropriate permission.
	 * <LI>Check the locking state of the application. If locked then return
	 * null otherwise continue.
	 * <LI>If the application is a singleton and already has a running instance
	 * then throw SingletonException.
	 * <LI>Calls the launchSpecific() method to create and start an application
	 * instance.
	 * <LI>Returns the <code>ApplicationHandle</code> returned by the 
	 * launchSpecific()
	 * </UL>
	 * The caller has to have ApplicationAdminPermission(applicationPID,
	 * "launch") in order to be able to perform this operation.
	 * 
	 * The <code>Map</code> argument of the launch method contains startup 
	 * arguments for the
	 * application. The keys used in the Map can be standard or application
	 * specific. MEG defines the
	 * #### .osgi.triggeringevent (contained funny character)
	 * key to be used to
	 * pass the triggering event to a scheduled application (see [ref]), however
	 * in the future it is possible that other well-known keys will be defined.
	 * To avoid unwanted clashes of keys, the following rules should be applied:
	 * <ul>
	 *   <li>The keys starting with the dash (-) character are application
	 *       specific, no well-known meaning should be associated with them.</li>
	 *   <li>Well-known keys should follow the reverse domain name based naming.
	 *       In particular, the keys standardized in OSGi should start with
	 *       <code>org.osgi.</code>.</li>
	 * </ul>
	 * 
	 * @param arguments
	 *            Arguments for the newly launched application, may be null
	 * 
	 * @return the registered ApplicationHandle, which represents the newly 
	 *         launched application instance
	 * 
	 * @throws SingletonException
	 *             if the call attempts to launch a second instance of a
	 *             singleton application
	 * @throws SecurityException
	 *             if the caller doesn't have "launch"
	 *             ApplicationAdminPermission for the application.
	 * @throws Exception
	 *             if starting the application(s) failed
	 * @throws IllegalStateException
	 *             if the application descriptor is unregistered
	 */
	public final ApplicationHandle launch(Map arguments)
			throws SingletonException, Exception {
		delegate.launch(arguments);
		return launchSpecific(arguments);
	}

	/**
	 * Called by launch() to create and start a new instance in an application
	 * model specific way. It also creates and registeres the application handle
	 * to represent the newly created and started instance and registeres it.
	 * 
	 * @param arguments
	 *            the startup parameters of the new application instance, may be
	 *            null
	 * 
	 * @return the registered application model
	 *         specific application handle for the newly created and started
	 *         instance.
	 * 
	 * @throws Exception
	 *             if any problem occures.
	 */
	protected abstract ApplicationHandle launchSpecific(Map arguments)
			throws Exception;

	/**
	 * Schedules the application at a specified event. Schedule information
	 * should not get lost even if the framework or the device restarts so it
	 * should be stored in a persistent storage. It has to register the returned
	 * service.
	 * 
	 * @param arguments
	 *            the startup arguments for the scheduled application, may be
	 *            null
	 * @param topic
	 *            specifies the topic of the triggering event, it may contain a
	 *            trailing asterisk as wildcard, the empty string is treated as
	 *            "*", must not be null
	 * @param eventFilter
	 *            specifies and LDAP filter to filter on the properties of the
	 *            triggering event, may be null
	 * @param recurring
	 *            if the recurring parameter is false then the application will
	 *            be launched only once, when the event firstly occurs. If the
	 *            parameter is true then scheduling will take place for every
	 *            event occurrence; i.e. it is a recurring schedule
	 * 
	 * @return the registered scheduled application service
	 * 
	 * @throws NullPointerException
	 *             if the topic is <code>null</code>
	 * @throws IOException
	 *             may be thrown if writing the information about the scheduled
	 *             application requires operation on the permanent storage and
	 *             I/O problem occurred.
	 * @throws SecurityException
	 *             if the caller doesn't have "schedule"
	 *             ApplicationAdminPermission for the application.
	 * @throws IllegalStateException
	 *             if the application descriptor is unregistered
	 */
	public final ScheduledApplication schedule(Map arguments, String topic,
			String eventFilter, boolean recurring) throws IOException {
		return delegate.schedule(arguments, topic, eventFilter, recurring);
	}

	/**
	 * Sets the lock state of the application. If an application is locked then
	 * launching a new instance is not possible. It does not affect the already
	 * launched instances.
	 * 
	 * @throws SecurityException
	 *             if the caller doesn't have "lock" ApplicationAdminPermission
	 *             for the application.
	 * @throws IllegalStateException
	 *             if the application descriptor is unregistered
	 */
	public final void lock() {
		delegate.lock();
	}
	
	/**
	 * This method is used to notify the container implementation that the
	 * corresponding application has been locked and it should update the
	 * <code>application.locked</code> service property accordingly.
	 */
	protected abstract void lockSpecific();

	/**
	 * Unsets the lock state of the application.
	 * 
	 * @throws SecurityException
	 *             if the caller doesn't have "lock" ApplicationAdminPermission
	 *             for the application.
	 * @throws IllegalStateException
	 *             if the application descriptor is unregistered
	 */
	public final void unlock() {
		delegate.unlock();
	}
	
	/**
	 * This method is used to notify the container implementation that the
	 * corresponding application has been unlocked and it should update the
	 * <code>application.locked</code> service property accordingly.
	 */
	protected abstract void unlockSpecific();

	public interface Delegate {
		void setApplicationDescriptor(ApplicationDescriptor d, String pid );

		boolean isLocked();

		void lock();

		void unlock();

		ScheduledApplication schedule(Map args, String topic, String filter,
				boolean recurs);

		void launch(Map arguments) throws Exception;
	}

	Delegate	delegate;
	String							pid;

	static Class					implementation;
	static String					cName;

	{
		try {
			cName = System
					.getProperty("org.osgi.vendor.application.ApplicationDescriptor");
			implementation = Class.forName(cName);
		}
		catch (Throwable t) {
			// Ignore
		}
	}

}